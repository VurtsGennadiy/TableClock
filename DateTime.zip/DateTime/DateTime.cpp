#include "DateTime.h"
#include <Arduino.h>

//const uint16_t setTimeoutTime = 30000;
bool timeoutFlag = false;

// чтение объекта DateTime из последовательного порта
// DateTime DateTime::setDateTimeFromSerial() {
	// timeoutFlag = false;
	// Serial.begin(9600);
  // DateTime setDateTime;
  // setDateTime.Hour = setDateTime.readHourFromSerial();
  // if (timeoutFlag) {
	// Serial.println("\nВышло время ожидания ввода, повторите попытку");
	// return setDateTime;  
  // }
  // setDateTime.Minute = setDateTime.readMinuteFromSerial();
  // setDateTime.Day = setDateTime.readDayFromSerial();
  // setDateTime.Date = setDateTime.readDateFromSerial();
  // setDateTime.Month = setDateTime.readMonthFromSerial();
  // setDateTime.Year = setDateTime.readYearFromSerial();
  // Serial.println("Время успешно записано!");
  // setDateTime.printToSerial();
  // return setDateTime;
// }

void DateTime::setDateTimeFromSerial() {
	timeoutFlag = false;
	Serial.begin(9600);
  Hour = readHourFromSerial();
  if (timeoutFlag) {
	Serial.println("\nВышло время ожидания ввода, повторите попытку");
	return;  
  }
  Minute = readMinuteFromSerial();
  Day = readDayFromSerial();
	Date = readDateFromSerial();
  Month = readMonthFromSerial();
  Year = readYearFromSerial();
  Serial.println("Время успешно записано!");
  printToSerial();
  return;
}

// чтение часа из последовательного порта
byte DateTime::readHourFromSerial(){
  timeoutFlag = false;
  bool isReadHour = false;  
  uint32_t startSetTime = millis();
  byte hour;
  Serial.print("Введите время чч: "); 
  while (!isReadHour) {
    if (Serial.available()) {
        hour = Serial.parseInt();
          if (hour >= 0 and hour <=24) {
           isReadHour = true;
           Serial.println(hour);
		   
          }
          else Serial.print("\nНеверный формат, введите число от 0 до 24.\nВведите время чч: ");            
    }
	if (millis() - startSetTime > setTimeoutTime) {
		timeoutFlag = true;
		break;
	}
	}
	return hour;
}

// чтение минуты из последовательного порта
byte DateTime::readMinuteFromSerial(){
  bool isReadMinute = false;
  byte minute;
  Serial.print("Введите время мм: "); 
  while (!isReadMinute) {
    if (Serial.available()) {
        minute = Serial.parseInt();
          if (minute >= 0 and minute <=59) {
           isReadMinute = true;
           Serial.println(minute);
          }
          else Serial.print("\nНеверный формат, введите число от 0 до 59.\nВведите время мм: ");            
    }
  }
  return minute;
}

// чтение дня недели из последовательного порта
byte DateTime::readDayFromSerial(){
  bool isReadDay = false;
  byte day;
  Serial.print("Введите день недели в формате: 1 - понедельник, 2 - вторник ... 7 - воскресенье: "); 
  while (!isReadDay) {
    if (Serial.available()) {
        day = Serial.parseInt();
          if (day >= 1 and day <=7) {
           isReadDay = true;
            switch (day){
              case 1: Serial.println("Понедельник ");
                break;
              case 2: Serial.println("Вторник ");
                break;
              case 3: Serial.println("Среда ");
                break;
              case 4: Serial.println("Четверг ");
                break;
              case 5: Serial.println("Пятница ");
                break;
              case 6: Serial.println("Суббота ");
                break;
              case 7: Serial.println("Воскресенье ");
                break;
            }       
          }
          else Serial.print("\nНеверный формат, введите число от 1 до 7.\nВведите день недели в формате: 1 - понедельник, 2 - вторник ... 7 - воскресенье: ");            
    }
  }
  return day;
}

// чтение даты из последовательного порта
byte DateTime::readDateFromSerial(){
  bool isReadDate = false;
  byte date;
  Serial.print("Введите дату: "); 
  while (!isReadDate) {
    if (Serial.available()) {
        date = Serial.parseInt();
          if (date >= 1 and date <=31) {
           isReadDate = true;
           Serial.println(date);
          }
          else Serial.print("\nНеверный формат, введите число от 1 до 31.\nВведите дату: ");            
    }
  }
  return date;
}

// чтение месяца из последовательного порта
byte DateTime::readMonthFromSerial(){
  bool isReadMonth = false;
  byte month;
  Serial.print("Введите месяц: "); 
  while (!isReadMonth) {
    if (Serial.available()) {
        month = Serial.parseInt();
          if (month >= 1 and month <=12) {
           isReadMonth = true;
           Serial.println(month);
          }
          else Serial.print("\nНеверный формат, введите число от 1 до 12.\nВведите месяц: ");            
    }
  }
  return month;
}

// чтение года из последовательного порта
byte DateTime::readYearFromSerial(){
  bool isReadYear = false;
  byte year;
  Serial.print("Введите год: "); 
  while (!isReadYear) {
    if (Serial.available()) {
        year = Serial.parseInt();
          if (year >= 00 and year < 100) {
           isReadYear = true;
           Serial.println(year);
          }
          else Serial.print("\nНеверный формат, введите число от 00 до 99.\nВведите год: ");            
    }
  }
  return year;
}

// вывод объекта DateTime в последовательный порт
void DateTime::printToSerial() {
	Serial.print("Текущее время: ");
  switch (Day){
    case 1: Serial.print("Понедельник ");
      break;
    case 2: Serial.print("Вторник ");
      break;
    case 3: Serial.print("Среда ");
      break;
    case 4: Serial.print("Четверг ");
      break;
    case 5: Serial.print("Пятница ");
      break;
    case 6: Serial.print("Суббота ");
      break;
    case 7: Serial.print("Воскресенье ");
      break;
  }
  Serial.print(Date);
  Serial.print(".");
  Serial.print(Month);
  Serial.print(".");
  Serial.print(Year);
  Serial.print("\t");
  Serial.print(Hour);
  Serial.print(":");
  Serial.print(Minute);
  Serial.print(":");
  Serial.println(Second);
}
	