#pragma once // для того чтобы не подключить библиотеку более 1 раза
#include <Arduino.h> // обязательно подключаем библиотеку из папки библиотек

/* в этом файле только объявляем методы класса, реализация этих методов в файле DateTime.cpp */
// объявляем класс
class DateTime {
	
	public:
	  const uint16_t setTimeoutTime = 30000; // таймаут установки времени
	  
	  byte Hour = 0; // часы
	  byte Minute = 0; // минуты
	  byte Second = 0; // секунды
	  byte Day = 1; // день недели
	  byte Date = 1; // дата
	  byte Month = 1; // месяц
	  byte Year = 00; // год
	
		byte readHourFromSerial(); // чтение часа из последовательного порта
		byte readMinuteFromSerial(); // чтение минуты из последовательного порта
		byte readDayFromSerial(); // чтение дня недели из последовательного порта
		byte readDateFromSerial(); // чтение даты из последовательного порта
		byte readMonthFromSerial(); // чтение месяца из последовательного порта
		byte readYearFromSerial(); // чтение года из последовательного порта
		
		void setDateTimeFromSerial(); // запись объекта DateTime из последовательного порта
		void printToSerial(); // вывод объекта DateTime в последовательный порт
};
